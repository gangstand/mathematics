from django.contrib import admin
from oge.models import BlockAlgebraOge, BlockGeometriaOge, VariantOge
admin.site.register(VariantOge)
admin.site.register(BlockAlgebraOge)
admin.site.register(BlockGeometriaOge)