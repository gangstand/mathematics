from django.contrib import admin
from ege.models import BlockAlgebraEge, BlockGeometriaEge, VariantEge
admin.site.register(VariantEge)
admin.site.register(BlockAlgebraEge)
admin.site.register(BlockGeometriaEge)