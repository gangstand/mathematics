Vue.createApp({
  delimiters: ['[[', ']]'],
  data() {
    return {
      agree: ''
    }
  }
}).mount('#checking')